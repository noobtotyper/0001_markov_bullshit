# QUICK DEMO
Usage to output to a file named bs.html:
python3 markov_bullshitter.py > bs.html

Usage to see in console:
python3 markov_bullshitter.py

# THINGS THAT SHOULD BE CHANGED
- The corpus, either add a large file instead, or several files and concatenate them.
- The input html file, obviously you want to edit your own html file.